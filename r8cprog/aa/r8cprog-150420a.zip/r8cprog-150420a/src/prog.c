//****************************************************************
//	R8C プログラマ
//
//	プログラミング部分
//
//	2009.6.2	KAWAKAMI Yukio
//****************************************************************

#if defined(__CYGWIN__) || defined(__MINGW32__)
#include <windows.h>
#else
#include <termios.h>
#endif

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>

#include "conf.h"
#include "mot.h"
#include "com.h"
#include "prog.h"
#include "main.h"

extern COMDAT	Com;
extern FILE	*Out;	// メッセージ出力先
extern DEVICE_CONF	Device[DEVICE_MAX];
extern PROG_CONF	Prog[PROG_MAX];
extern OPTION		Option;

typedef struct _DATA_BUFF {
	long	start;
	long	end;
	unsigned char	*buff;
} DATA_BUFF;

int mem_dump(long adrs, unsigned char	buff[])
{
	int i;
	for (i = 0; i < 256; i++){
		int j;
		unsigned char	d;
		d = 0xFF;
		for (j = 0; j < 256; j++){
			d &= buff[j];
		}
		// 0xFF 以外のデータがある
		if (d != 0xFF) {
			if ((i % 16) == 0) {
				fprintf(Out, "%08X: ", (unsigned int)adrs + i);
			}
			fprintf(Out, " %02X ", buff[i]);
			if ((i  % 16) == 0x0f)
			fprintf(Out, "\n");
			fflush(Out);
		}
	}
	return 0;
}

//********************************************************
//	プログラム開始
//********************************************************
int program(COMDAT *com){
	int		i;
	int		ret = 0;
	PROG_CONF	*prog;
	DEVICE_CONF	*device;
	FILE		*fp;
	DATA_BUFF	data_buff[AREA_MAX*2];
	int			buff_n = 0;
	int			block;
	int			block_n = 0;
	long		old_block = -1;

	// プログラマ選択
	prog = NULL;
	for (i = 0; i < PROG_MAX; i++){
		if (strcmp(Prog[i].name, Option.prog) == 0){
			prog = &Prog[i];
			break;
		}
	}
	if (prog == NULL){
		fprintf(stdout, "Programmer setting not found : %s\n", Option.prog);
		return 1;
	} else {
		if (Option.verbose_flag){
			fprintf(Out, "Programmer : %s\n", Option.prog);
		}
	}

	// デバイス選択
	if (!Option.device[0]){
		device = &Device[0];	// デバイス指定なし
		fprintf(Out, "Device : unknown\n");
	} else {
		device = NULL;
		for (i = 0; i < DEVICE_MAX; i++){
			if (strcmp(Device[i].name, Option.device) == 0){
				device = &Device[i];
				break;
			}
		}
		if (device == NULL){
			fprintf(stdout, "Device setting not found : %s\n", Option.device);
			return 1;
		} else {
			if (Option.verbose_flag){
				fprintf(Out, "Device : %s\n", Option.device);
			}
		}
	}


	// データバッファメモリ確保
	for (i = 0; i < AREA_MAX; i++){
		size_t	s;
		if (device->data_area[i][0] == 0)	break;
		data_buff[buff_n].start = device->data_area[i][0];
		data_buff[buff_n].end = device->data_area[i][1];
		s = device->data_area[i][1] - device->data_area[i][0] + 1;
		data_buff[buff_n].buff = malloc(s);
		if (data_buff[buff_n].buff){
			memset(data_buff[buff_n].buff, 0xFF, s);
		}
		buff_n++;
	}
	for (i = 0; i < AREA_MAX; i++){
		size_t	s;
		if (device->rom_area[i][0] == 0)	break;
		data_buff[buff_n].start = device->rom_area[i][0];
		data_buff[buff_n].end = device->rom_area[i][1];
		s = device->rom_area[i][1] - device->rom_area[i][0] + 1;
		data_buff[buff_n].buff = malloc(s);
		if (data_buff[buff_n].buff){
			memset(data_buff[buff_n].buff, 0xFF, s);
		}
		buff_n++;
	}

	if (Option.mot_fname[0]){
		// MOTファイル読み込み
		fp = open_mot(Option.mot_fname);
		if (fp == NULL)	goto QUIT;
		while(!feof(fp)){
			unsigned char	buff[1024];
			long			adrs;
			int				j, n;
			unsigned char	*p;

			n = read_mot(fp, buff, sizeof(buff), &adrs);
			if (n <= 0)	break;
			for (i = 0; i < buff_n; i++){
				if ((adrs >= data_buff[i].start)&&
					(adrs <= data_buff[i].end)){
					break;
				}
			}
			if (i >= buff_n){
				fprintf(stdout, "Data address is out of device area : %lXh\n", adrs);
				close_mot(fp);
				ret = 1;
				goto QUIT;
			}
			p = data_buff[i].buff + (adrs - data_buff[i].start);
			for (j = 0; j < n; j++){

				// 書き換えるブロック数取得
				if ((adrs & 0xFFFF00) != old_block){
					old_block = adrs & 0xFFFF00;
					block_n++;
				}

				if (adrs > data_buff[i].end){
					// 次のブロックで続けてみる
					if ((++i >= buff_n)||
						(adrs < data_buff[i].start)||
						(adrs > data_buff[i].end)){
						fprintf(stdout, "Data address is out of device area : %lXh\n", adrs);
						close_mot(fp);
						ret = 1;
						goto QUIT;
					}
					p = data_buff[i].buff;
				}
				*p++ = buff[j];
				adrs++;
			}
		}
		close_mot(fp);
	}

	// プログラマ接続
	ret = connect_programmer(com);
	if (ret < 0)	goto QUIT;

	if (Option.erase_flag){
		// イレース処理
		progress(0, -1);	// プログレス初期化
		if ((Option.erase_chip)||(!Option.device[0])){	// デバイス指定が無い
			// チップイレース
			fprintf(Out, "Chip Erase\n");
			fflush(Out);
			if (chip_erase(com)){
				ret = 1;
				goto DISCONNECT;
			}
			wait_ready(com);	// 終了待ち
			progress(1, 1);		// プログレス表示
		} else {
			if (!Option.verbose_flag){
				fprintf(Out, "Erase\n");
				fflush(Out);
			}
			if (!Option.erase_rom && !Option.erase_data){
				// 最小限消去
				for (block = 0; block < buff_n; block++){
					unsigned char	d, *p;
					long			adrs;
					p = data_buff[block].buff;
					adrs = data_buff[block].start;
					d = 0xFF;
					for (i = 0; i < (data_buff[block].end - data_buff[block].start + 1); i++){
						d &= *p++;
					}
					if (d != 0xFF){
						// 書き込むデータがあるのでブロック消去
						if (Option.verbose_flag){
							fprintf(Out, "Erase : %lXh\n", adrs);
							fflush(Out);
						}
						if (block_erase(com, adrs)){
							ret = 1;
							goto DISCONNECT;
						}
					}
					wait_ready(com);		// 終了待ち
					progress(block+1, buff_n);	// プログレス
				}
				progress(buff_n, buff_n);	// プログレス 100%
			} else {
				int	pg = 0;
				if (Option.erase_rom){
					for (i = 0; i < AREA_MAX; i++){
						if (device->rom_area[i][0] == 0)	break;
						if (Option.verbose_flag){
							fprintf(Out, "Erase : %lXh\n",
									device->rom_area[i][0]);
							fflush(Out);
						}
						if (block_erase(com, device->rom_area[i][0])){
							ret = 1;
							goto DISCONNECT;
						}
						wait_ready(com);	// 終了待ち
						progress(++pg, buff_n);	// プログレス
					}
				}
				if (Option.erase_data){
					for (i = 0; i < AREA_MAX; i++){
						if (device->data_area[i][0] == 0)	break;
						if (Option.verbose_flag){
							fprintf(Out, "Erase : %lXh\n",
									device->data_area[i][0]);
							fflush(Out);
						}
						if (block_erase(com, device->data_area[i][0])){
							ret = 1;
							goto DISCONNECT;
						}
						wait_ready(com);	// 終了待ち
						progress(++pg, buff_n);	// プログレス
					}
				}
				progress(buff_n, buff_n);	// プログレス
			}
		}
	}

	if (Option.mot_fname[0] && Option.write_flag){
		// 書き込み
		int	pg = 0;
		progress(0, -1);	// プログレス初期化
		if (!Option.verbose_flag){
			fprintf(Out, "Write\n");
			fflush(Out);
		}

		for (block = 0; block < buff_n; block++){
			unsigned char	d, *p;
			long			adrs;
			p = data_buff[block].buff;
			adrs = data_buff[block].start;
			while(adrs < data_buff[block].end){
				unsigned char	*start;
				start = p;
				d = 0xFF;
				for (i = 0; i < 256; i++){
					d &= *p++;
				}
				//if (adrs == 0x00FF00){	// IDのあるブロック
				//	for (i = 0; i < 7; i++){
				//		d &= Option.id[i];
				//	}
				//}
				if (d != 0xFF){
					// FFh以外データがあるのでブロック書き込み
					if (Option.verbose_flag){
						fprintf(Out, "Write : %lXh\n", adrs);
						fflush(Out);
					}
					//if (adrs == 0x00FF00){	// IDのあるブロック
					//	// ID値を上書き
					//	start[0xDF] = Option.id[0];
					//	start[0xE3] = Option.id[1];
					//	start[0xEB] = Option.id[2];
					//	start[0xEF] = Option.id[3];
					//	start[0xF3] = Option.id[4];
					//	start[0xF7] = Option.id[5];
					//	start[0xFB] = Option.id[6];
					//}
					if (page_write(com, adrs, start)){
						ret = 1;
						goto DISCONNECT;
					}
					// 書き込み終了待ち
					wait_ready(com);
					progress(++pg, block_n);	// プログレス
				}
				adrs += 256;
			}
		}
		progress(block_n, block_n);	// プログレス 100%
	}

#if 1
	if (Option.read_flag){
		// 読み出し
		progress(0, -1);	// プログレス初期化
		if (!Option.verbose_flag){
			fprintf(Out, "Read\n");
			fflush(Out);
		}
		{
			unsigned char	buff[256];
			long			adrs;

			adrs = 0x3000;
			while(adrs < 0x3800){
				if (page_read(com, adrs, buff)){
					goto   DISCONNECT;
				} else {
					mem_dump(adrs, buff);
				}
				adrs += 256;
			}

			adrs = 0x8000;
			while(adrs < 0x10000){
				if (page_read(com, adrs, buff)){
					goto   DISCONNECT;
				} else {
					mem_dump(adrs, buff);
				}
				adrs += 256;
			}
		}
	}
#endif

	if (Option.mot_fname[0] && Option.verify_flag){
		// ベリファイ
		int	pg = 0;
		progress(0, -1);	// プログレス初期化
		if (!Option.verbose_flag){
			fprintf(Out, "Verify\n");
			fflush(Out);
		}
		for (block = 0; block < buff_n; block++){
			unsigned char	d, *p;
			long			adrs;

			p = data_buff[block].buff;
			adrs = data_buff[block].start;

			while(adrs < data_buff[block].end){
				unsigned char	*start;
				unsigned char	buff[256];
				start = p;
				d = 0xFF;
				for (i = 0; i < 256; i++){
					d &= *p++;
				}
				//if (adrs == 0x00FF00){	// IDのあるブロック
				//	for (i = 0; i < 7; i++){
				//		d &= Option.id[i];
				//	}
				//}
				if (d != 0xFF){
					unsigned char	*v;
					// FFh以外のデータがあるのでベリファイ
					if (Option.verbose_flag){
						fprintf(Out, "Verify : %lXh", adrs);
						fflush(Out);
					}
					//if (adrs == 0x00FF00){	// IDのあるブロック
					//	// ID値を上書き
					//	start[0xDF] = Option.id[0];
					//	start[0xE3] = Option.id[1];
					//	start[0xEB] = Option.id[2];
					//	start[0xEF] = Option.id[3];
					//	start[0xF3] = Option.id[4];
					//	start[0xF7] = Option.id[5];
					//	start[0xFB] = Option.id[6];
					//}
					if (page_read(com, adrs, buff)){
						ret = 1;
						goto DISCONNECT;
					}
					v = start;
					for (i = 0; i < 256; i++){
						if (*v != buff[i]){
							if (!Option.verbose_flag){
								fprintf(Out, "\nVerify : %lXh", adrs);
							}
							fprintf(Out, "\t%lXh:%02X->%02X ERROR\n", adrs + i,
										*v, buff[i]);
							ret = 1;
							break;
						}
						v++;
					}
					if (Option.verbose_flag){
						fprintf(Out, "\n");
						fflush(Out);
					}
					progress(++pg, block_n);	// プログレス
					if (ret)	break;
				}
				adrs += 256;
			}
			if (ret)	break;
		}
		if (ret == 0){
			progress(block_n, block_n);	// プログレス 100%
		}
	}

	if (Option.erase_flag || Option.write_flag || Option.verify_flag){
		// 新しいID値読み込み
		unsigned char	buff[256];

		if (page_read(com, 0x00FF00, buff)){
			ret = 1;
			goto DISCONNECT;
		}
		fprintf(Out, "New ID : %02X:%02X:%02X:%02X:%02X:%02X:%02X\n",
				buff[0xDF], buff[0xE3], buff[0xEB], buff[0xEF],
				buff[0xF3], buff[0xF7], buff[0xFB]);
	}


  DISCONNECT:
	// プログラマ接続解除
	disconnect_programmer(com);

  QUIT:
	// データバッファメモリ開放
	for (i = 0; i < buff_n; i++){
		free(data_buff[i].buff);
	}
	return ret;
}


//********************************************************
//	SRD BUSY待ち
//********************************************************
int wait_ready(COMDAT *com){
	int		tm;
	int		stat;

	tm = 0;
	for (;;){
		stat = read_status(com);
		if (stat < 0)	stat = 0;
		if ((stat & (R8C_SRD_READY|R8C_SRD_ERASE_ERROR|R8C_SRD_PROG_ERROR))
			== R8C_SRD_READY)	break;
		msleep(10);
		if (++tm >= 200){
			fprintf(stdout, "BUSY time out\n");
			return 1;
		}
	}
	return 0;
}


//********************************************************
//	チップ消去
//********************************************************
int chip_erase(COMDAT *com){

	if (wait_ready(com))	return 1;

	send_command(com, R8C_CLEAR_SRD);

	send_command(com, R8C_ERASE_ALL_BLOCK);
	com_write(com, 0xD0);

	return 0;
}


//********************************************************
//	ブロック消去
//********************************************************
int block_erase(COMDAT *com, long adrs){

	if (wait_ready(com))	return 1;

	send_command(com, R8C_CLEAR_SRD);

	send_command(com, R8C_BLOCK_ERASE);
	com_write(com, (unsigned char)(adrs >> 8));
	com_write(com, (unsigned char)(adrs >> 16));
	com_write(com, 0xD0);

	return 0;
}


//********************************************************
//	ページ書き込み
//********************************************************
int page_write(COMDAT *com, long adrs, unsigned char *buff){

	if (wait_ready(com))	return 1;

	send_command(com, R8C_CLEAR_SRD);

	send_command(com, R8C_PAGE_PROGRAM);
	com_write(com, (unsigned char)(adrs >> 8));
	com_write(com, (unsigned char)(adrs >> 16));
	com_flush(com);
	com_write_bytes(com, buff, 256);
	com_flush(com);

	return 0;
}


//********************************************************
//	ページ読み込み
//********************************************************
int page_read(COMDAT *com, long adrs, unsigned char *buff){

	send_command(com, R8C_PAGE_READ);
	com_write(com, (unsigned char)(adrs >> 8));
	com_write(com, (unsigned char)(adrs >> 16));
	if (com_read_bytes(com, buff, 256))	return 1;

	return 0;
}


//********************************************************
//	プログラマ接続
//********************************************************
int connect_programmer(COMDAT *com){
	int		i;

	if (com_open(com, Option.port, 9600))	return -1;

	// ボーレート同期
	send_command(com, R8C_B9600);

	msleep(100);	// 0.1秒

	for (i = 0; i < 16; i++){
		send_command(com, 0);
		com_flush(com);
	}

	// 反応確認
	send_command(com, R8C_B9600);
	if (read_response(com, 2000) != R8C_B9600){
		fprintf(stdout, "Programmer or Device not responsed\n");
		return -1;
	}

	if (Option.speed > 9600){
		// ボーレート変更
		unsigned char	b;

		switch(Option.speed){
		  case 19200:
			b = R8C_B19200;
			send_command(com, b);
			break;
		  case 38400:
			b = R8C_B38400;
			send_command(com, b);
			break;
		  case 57600:
			b = R8C_B57600;
			send_command(com, b);
			break;
		  case 115200:
			b = R8C_B115200;
			send_command(com, b);
			break;
		  default:
			b = (unsigned char)(8000000L/16/Option.speed - 1);
			send_command(com, R8C_BAUD_SET);
			com_write(com, b);
			break;
		}
		if (read_response(com, 1000) != b){
			fprintf(stdout, "Baudrate change error : %ld\n", Option.speed);
			return -1;
		}

		// シリアルポートボーレート変更
		com_close(com);
		if (com_open(com, Option.port, Option.speed)){
			return -1;
		}
	}

	// バージョン
	send_command(com, R8C_VERSION_INFO);
	for (i = 0; i < 8; i++){
		int		c;
		c = read_response(com, 100);
		if (c < 0){
			fprintf(stdout, "Version Info. read error\n");
			return -1;
		}
		if (Option.verbose_flag){
			if (i == 0)	fprintf(Out, "Version Info. : ");
			fprintf(Out, "%c", (unsigned char)c);
		}
	}
	if (Option.verbose_flag){
		fprintf(Out, "\n");
	}

	// ステータスレジスタ
	i = read_status(com);
	if (i >= 0){
		if (Option.verbose_flag){
			fprintf(Out, "Status : %04X\n", i);
		}
	} else {
		fprintf(stdout, "Status read error\n");
		return -1;
	}

	// ID認証
	send_command(com, R8C_ID_CHECK);
	com_write(com, 0xDF);
	com_write(com, 0xFF);
	com_write(com, 0x00);
	com_write(com, 0x07);
	for (i = 0; i < 7; i++){
		com_write(com, Option.id[i]);
	}

	send_command(com, R8C_CLEAR_SRD);

	i = read_status(com);
	if ((i & R8C_SRD_IDENTIFIED) != R8C_SRD_IDENTIFIED){
		fprintf(stdout, "ID check error\n");
		return -1;
	}
	if (Option.verbose_flag){
		fprintf(Out, "ID check OK : %02X:%02X:%02X:%02X:%02X:%02X:%02X\n",
				Option.id[0], Option.id[1], Option.id[2], Option.id[3],
				Option.id[4], Option.id[5], Option.id[6]);
	}

	return 0;
}


//********************************************************
//	プログラマ接続断
//********************************************************
void disconnect_programmer(COMDAT *com){

	send_command(com, R8C_B9600);
	com_close(com);
}


//********************************************************
//	プログラマ ステータスレジスタ読み込み
//********************************************************
int read_status(COMDAT *com){
	int		r;
	int		s;

	send_command(com, R8C_READ_SRD);
	r = read_response(com, 100);
	if (r < 0)	return -1;
	s = r;
	r = read_response(com, 10);
	if (r < 0)	return -1;
	s |= r << 8;
	return s;
}


//********************************************************
//	プログラマコマンドbyte送信
//********************************************************
int send_command(COMDAT *com, unsigned char command){
	int		r;

	msleep(R8C_DELAY);
	r = com_write(com, command);
	com_flush(com);
	return r;
}


//********************************************************
//	プログラマレスポンス受信
//********************************************************
int read_response(COMDAT *com, int timeout){

	while(com_buff_n(com) == 0){
		msleep(10);			// 10ms
		if (com_buff_n(com))	break;
		timeout -= 10;
		if (timeout <= 0)	return -1;	// timeout
	}
	return com_read(com);
}


//********************************************************
//	プログレスバー出力
//	max == -1	: 初期化
//********************************************************
void progress(int n, int max){
	static int	out_n;
	long		l;

	if (max <= 0){
		out_n = 0;
		return;
	}

	if (Option.verbose_flag)	return;

	if (n > max)	n = max;

	l = (long)n * 50L;
	l += max/2;
	l /= (long)max;
	while(l > out_n){
		fputc('#', Out);
		out_n++;
		if (out_n == 50){
			fputc('\n', Out);
		}
	}
	fflush(Out);
}
