#ifndef _MAIN_H_
#define	_MAIN_H_

int search_path_file(char *argv0, char *conf_fname);
void read_command_line(OPTION *opt, int argc, char *argv[], char *conf_file);
int file_exist(char *fname);

int read_mot_id(char *fname, unsigned char id[]);
int read_id_file(char *fname, unsigned char id[]);

void view_device_list(void);
void view_programmer_list(void);
void view_help(void);

int cmp_device(const void *d1, const void *d2);
int cmp_prog(const void *p1, const void *p2);

#endif	// _MAIN_H_
