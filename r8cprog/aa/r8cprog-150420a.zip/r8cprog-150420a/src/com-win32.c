#if defined(__CYGWIN__) || defined(__MINGW32__)

//*******************************************************
//	Windows用シリアルポート読み書き
//*******************************************************

#include <windows.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "com.h"


//*******************************************************
//	シリアルポートオープン
//*******************************************************
int com_open(COMDAT *com, char *dev_name, long speed){
	HANDLE	id;
	char	buff[16];
	COMSTAT	cs;
	DWORD	er;

	com->idCom = 0;

	com->time_out.ReadIntervalTimeout = 1000;
	com->time_out.ReadTotalTimeoutMultiplier = 0;
	com->time_out.ReadTotalTimeoutConstant = 1000;
	com->time_out.WriteTotalTimeoutMultiplier = 0;
	com->time_out.WriteTotalTimeoutConstant = 1000;

	if (*dev_name != '\\'){
		strcpy(buff, "\\\\.\\");
	} else {
		buff[0] = 0;
	}
	strcat(buff, dev_name);

	id = CreateFile(buff, GENERIC_READ|GENERIC_WRITE, 0, NULL, OPEN_EXISTING,
				FILE_ATTRIBUTE_NORMAL, NULL);

	if ((id < 0)||
	    (SetupComm(id, RX_BUFF_SIZE, TX_BUFF_SIZE) == FALSE)||
	    (SetCommTimeouts(id, &(com->time_out)) == FALSE)||
	    (PurgeComm(id, PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR) == FALSE)){
		fprintf(stdout, "%s not open\n", dev_name);
		return 1;
	}

	GetCommState(id, &(com->dcb));

	com->dcb.BaudRate = speed;
	com->dcb.fBinary = TRUE;
	com->dcb.fNull = FALSE;
	com->dcb.fOutxCtsFlow = FALSE;
	com->dcb.fOutxDsrFlow = FALSE;
	com->dcb.fDtrControl = DTR_CONTROL_DISABLE;
	com->dcb.fRtsControl = RTS_CONTROL_DISABLE;
	com->dcb.ByteSize = 8;
	com->dcb.Parity = NOPARITY;
	com->dcb.StopBits = ONESTOPBIT;
	com->dcb.fAbortOnError = FALSE;

	if (SetCommState(id, &(com->dcb)) == FALSE){
		fprintf(stdout, "SetCommState error\n");
		CloseHandle(com->idCom);
		return 1;
	}

	EscapeCommFunction(id, SETDTR|SETRTS|CLRBREAK);

	ClearCommBreak(id);

	com->idCom = id;

	ClearCommError(id, &er, &cs);

	return 0;
}


//*******************************************************
//	シリアルポートクローズ
//*******************************************************
void com_close(COMDAT *com){

	PurgeComm(com->idCom, PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR);
	CloseHandle(com->idCom);
}


//*******************************************************
//	シリアルポート読み込み
//*******************************************************
int com_read(COMDAT *com){
	DWORD	n;
	unsigned char	buff;

	do {
		if (ReadFile(com->idCom, &buff, 1, &n, NULL) == FALSE){
			n = CE_BREAK|CE_FRAME|CE_IOE|CE_RXOVER|CE_RXPARITY;
			ClearCommError(com->idCom, &n, NULL);			// エラー解除
			return -1;
		}
	} while(n == 0);

	return  (int)buff;
}


//*******************************************************
//	シリアルポート複数データ読み込み
//*******************************************************
int com_read_bytes(COMDAT *com, unsigned char *buff, int n){
	DWORD	nn;

	while(n > 0){
		if (ReadFile(com->idCom, buff, n, &nn, NULL) == FALSE){
			nn = CE_BREAK|CE_FRAME|CE_IOE|CE_RXOVER|CE_RXPARITY;
			ClearCommError(com->idCom, &nn, NULL);			// エラー解除
			return -1;
		} else {
			n -= nn;
			buff += nn;
		}
	}
	return 0;
}


//*******************************************************
//	シリアルポート書き込み
//*******************************************************
int com_write(COMDAT *com, unsigned char data){
	unsigned char	buff;
	DWORD	n;

	buff = data;

	if (WriteFile(com->idCom, &buff, 1, &n, NULL) == TRUE){
		return 0;
	} else {
		n = CE_IOE|CE_TXFULL;
		ClearCommError( com->idCom, &n, NULL );		// エラー解除
		return -1;
	}
}


//*******************************************************
//	シリアルポート複数データ書き込み
//*******************************************************
int com_write_bytes(COMDAT *com, unsigned char *buff, int n){
	DWORD	nn;

	while(n > 0){
		WriteFile(com->idCom, buff, n, &nn, NULL);
		if (nn > 0){
			n -= nn;
			buff += nn;
		} else {
			nn = CE_IOE|CE_TXFULL;
			ClearCommError(com->idCom, &nn, NULL);		// エラー解除
			return -1;
		}
	}

	return 0;
}


//*******************************************************
//	シリアルポート書き込みフラッシュ
//*******************************************************
void com_flush(COMDAT *com){

	FlushFileBuffers(com->idCom);
}


//*******************************************************
//	シリアル入力バッファのデータ数取得
//*******************************************************
int com_buff_n(COMDAT *com){
	DWORD	er;

	ClearCommError(com->idCom, &er, &(com->com_stat));
	return com->com_stat.cbInQue;
}


//*******************************************************
//	スピード定数取得
//*******************************************************
long com_get_speed_t(long speed){

	switch(speed){
	  case 50:	return 50;
	  case 75:	return 75;
	  case 110:	return 110;
	  case 134:	return 134;
	  case 150:	return 150;
	  case 200:	return 200;
	  case 300:	return 300;
	  case 600:	return 600;
	  case 1200:	return 1200;
	  case 1800:	return 1800;
	  case 2400:	return 2400;
	  case 4800:	return 4800;
	  case 9600:	return 9600;
	  case 19200:	return 19200;
	  case 38400:	return 38400;
	  case 57600:	return 57600;
	  case 115200:	return 115200;
	  case 230400:	return 230400;
	  default:	return 0;
	}
}


//********************************************************
//	1mSec単位でスリープ
//********************************************************
void msleep(int n){

	Sleep(n);
}

#endif
