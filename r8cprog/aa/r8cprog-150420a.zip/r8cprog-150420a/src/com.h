#ifndef _COM_H_
#define	_COM_H_


#if defined(__CYGWIN__) || defined(__MINGW32__)
#include <windows.h>
// ����M�o�b�t�@�̗ʂ̐ݒ�
#define	RX_BUFF_SIZE	4096
#define	TX_BUFF_SIZE	1024
//typedef long speed_t;
typedef struct {
	HANDLE			idCom;
	DCB				dcb;
	COMMTIMEOUTS	time_out;
	COMSTAT			com_stat;
} COMDAT;
#else
#include <termios.h>
typedef int	COMDAT;
#endif


int com_open(COMDAT *com, char *dev_name, long speed);
void com_close(COMDAT *com);
int com_read(COMDAT *com);
int com_read_bytes(COMDAT *com, unsigned char *buff, int n);
int com_write(COMDAT *com, unsigned char data);
int com_write_bytes(COMDAT *com, unsigned char *buff, int n);
void com_flush(COMDAT *com);
int com_buff_n(COMDAT *com);

void msleep(int n);


#if defined(__CYGWIN__) || defined(__MINGW32__)
long com_get_speed_t(long speed);
#else
speed_t com_get_speed_t(long speed);
#endif

#endif	// _COM_H_
