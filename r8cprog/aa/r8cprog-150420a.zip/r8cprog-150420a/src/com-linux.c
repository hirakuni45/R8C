#if !defined(__CYGWIN__) && !defined(__MINGW32__)

//*******************************************************
//	linux用シリアルポート読み書き
//*******************************************************

#include <assert.h>
#include <error.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <signal.h>
#include <linux/serial.h>
#include <sys/ioctl.h>

#include "com.h"

//*******************************************************
//	シリアルポートオープン
//*******************************************************
int com_open(COMDAT *com, char *dev_name, long speed){
	struct serial_struct serinfo;
	speed_t	spt;
	struct termios	opt;

	if (*com > 0)	com_close(com);
	
	*com = open(dev_name, O_RDWR | O_NOCTTY | O_NDELAY);
	if (*com < 0){
		fprintf(stdout, "Port not open : %s\n", dev_name);
		return -1;
	}

	fcntl(*com, F_SETFL, 0);		// read is blocking

	// 特殊ボーレート設定
	spt = com_get_speed_t(speed);
	if (spt == 0){	// 通常ボーレートでない場合
		if (ioctl(*com, TIOCGSERIAL, &serinfo)){
			//fprintf(stdout, "Not support TIOCGSERIAL\n");
			//com_close(com);
			//return -1;
			// プログラマ側でなんとかすることを期待して続ける
		} else {
			serinfo.flags &= ~ASYNC_SPD_MASK;
			serinfo.flags |= ASYNC_SPD_CUST;
			serinfo.custom_divisor = serinfo.baud_base/speed;
			if (ioctl(*com, TIOCSSERIAL, &serinfo)){
				fprintf(stdout, "Not support TIOCSSERIAL / %ld bps\n", speed);
				com_close(com);
				return -1;
			}
		}
		spt = B38400;	// 以降は 38400bpsと同じ
	}

	// 現在設定読み出し
	tcgetattr(*com, &opt);

	// ボーレート設定
	if (cfsetispeed(&opt, spt)){
		fprintf(stdout, "Baudrate set error : %ld bps\n", speed);
		com_close(com);
		return -1;
	}
	cfsetospeed(&opt, spt);

	// rawモード
	cfmakeraw(&opt);

	// 8bit, stop 1, no parity
	opt.c_cflag &= ~(CSTOPB|PARENB|CRTSCTS);
	opt.c_cflag |= CS8|CLOCAL;
	opt.c_cc[VTIME] = 0;
	opt.c_cc[VMIN] = 1;

	// XON/XOFFフロー禁止, BREAK, パリティエラー無視, モデム制御線無視
	opt.c_iflag &= ~(INLCR|IGNCR|IUCLC|IXON);
	opt.c_iflag |= IGNBRK|IGNPAR;

	opt.c_oflag = 0;
	

	// 設定適用
	tcsetattr(*com, TCSANOW, &opt);
	
	return 0;	
}


//*******************************************************
//	シリアルポートクローズ
//*******************************************************
void com_close(COMDAT *com){

	if (*com >= 0){
		close(*com);
		*com = -1;
	}
}


//*******************************************************
//	シリアルポート読み込み
//*******************************************************
int com_read(COMDAT *com){
	unsigned char	c;
	int		n;

	if (*com < 0)	return -1;

	do {
		n = read(*com, &c, 1);
		if (n < 0){
			fprintf(stdout, "com_read error\n");
			com_close(com);
			return -1;
		}
	} while(n == 0);

	return (int)c;
}


//*******************************************************
//	シリアルポート複数データ読み込み
//*******************************************************
int com_read_bytes(COMDAT *com, unsigned char *buff, int n){

	if (*com < 0)	return -1;

	while(n > 0){
		int	r;
		r = read(*com, buff, n);
		if (r < 0)	return -1;
		n -= r;
		buff += r;
	}

	return 0;
}


//*******************************************************
//	シリアルポート書き込み
//*******************************************************
int com_write(COMDAT *com, unsigned char data){

	if (*com < 0)	return -1;

	if (write(*com, &data, 1) != 1){
		fprintf(stdout, "com_write error\n");
		com_close(com);
		return -1;
	}
	return 0;
}


//*******************************************************
//	シリアルポート複数データ書き込み
//*******************************************************
int com_write_bytes(COMDAT *com, unsigned char *buff, int n){

	if (*com < 0)	return -1;

	if (write(*com, buff, n) != n){
		fprintf(stdout, "com_write_bytes error\n");
		com_close(com);
		return -1;
	}
	return 0;
}


//*******************************************************
//	シリアルポート書き込みフラッシュ
//*******************************************************
void com_flush(COMDAT *com){

	if (*com < 0)	return;

	tcflush(*com, TCIOFLUSH);
}


//*******************************************************
//	シリアル入力バッファのデータ数取得
//*******************************************************
int com_buff_n(COMDAT *com){
	int	n;

	if (*com < 0)	return -1;

	ioctl(*com, FIONREAD, &n);
	return n;
}


//*******************************************************
//	スピード定数取得
//*******************************************************
speed_t com_get_speed_t(long speed){

	switch(speed){
	  case 50:	return B50;
	  case 75:	return B75;
	  case 110:	return B110;
	  case 134:	return B134;
	  case 150:	return B150;
	  case 200:	return B200;
	  case 300:	return B300;
	  case 600:	return B600;
	  case 1200:	return B1200;
	  case 1800:	return B1800;
	  case 2400:	return B2400;
	  case 4800:	return B4800;
	  case 9600:	return B9600;
	  case 19200:	return B19200;
	  case 38400:	return B38400;
	  case 57600:	return B57600;
	  case 115200:	return B115200;
	  case 230400:	return B230400;
	  default:	return 0;
	}
}


//********************************************************
//	1mSec単位でスリープ
//********************************************************
void msleep(int n){
	usleep(n * 1000);
}

#endif
