//****************************************************************
//	R8C プログラマ
//
//	設定ファイル関連
//
//	2009.6.2	KAWAKAMI Yukio
//****************************************************************

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "conf.h"
#include "main.h"

extern FILE	*Out;	// メッセージ出力先

//****************************************************************
//	CONFファイル読み込み
//****************************************************************
int load_conf(char *conf_fname,
			  DEVICE_CONF device[], PROG_CONF prog[], OPTION *option){
	int		section = 0;
	FILE	*fp;


	fp = fopen(conf_fname, "rt");
	if (fp == NULL){
		fprintf(stdout, "File not open : %s\n", conf_fname);
		return -1;
	}
	//fprintf(Out, "Loading : %s\n", conf_fname);
	while(!feof(fp)){
		switch(section){
		  case 1:			// PROGRAMMER
			section = conf_prog(fp, prog);
			break;
		  case 2:			// DEVICE
			section = conf_device(fp, device);
			break;
		  default:			// DEFAULT
			section = conf_default(fp, option);
			break;
		}
		if (section < 0)	break;
	}
	fclose(fp);
	if (section < 0){
		return -1;
	} else {
		return 0;
	}
}

//****************************************************************
//	PROGRAMMERセクション読み込み
//****************************************************************
int conf_prog(FILE *fp, PROG_CONF prog[]){
	char	buff[1024];
	char	data[1024];
	char	name[16];
	PROG_CONF	*pg;
	int		i;

	pg = NULL;

	while(!feof(fp)){
		char *dummy;
		buff[0] = 0;
		dummy = fgets(buff, sizeof(buff), fp);
		if (buff[0] == 0)	break;

		if (buff[0] == '['){	// セクションが変わる
			str_upr(buff);
			if (strncmp(&buff[1], "DEVICE", 6) == 0)		return 2;
			if (strncmp(&buff[1], "DEFAULT",7) == 0)		return 0;
			if (strncmp(&buff[1], "PROGRAMMER", 10) != 0){
				fprintf(stdout, "Section name error : %s\n", buff);
				return -1;
			}
		} else if (sscanf(buff, " comment = %s", data) == 1){
			if (pg != NULL){
				get_comment(buff, data, 64);
				strcpy(pg->comment, data);
			}
		} else if (strchr(buff, '}') != NULL){	// これは最後から一つ前
			pg = NULL;
			// {} がある行に設定は書けないのは仕様です
		} else if (sscanf(buff, " %s", data) == 1){ // これは最後に置くこと
			if ((strchr(buff, '{') != NULL)&&(strlen(data) < 16)){
				strcpy(name, data);
				pg = NULL;
				for (i = 0; i < PROG_MAX; i++){
					if (prog[i].name[0] == 0)	break;
					if (strcmp(prog[i].name, name) == 0){
						pg = &prog[i];
						break;
					}
				}
				if ((pg == NULL)&&(i < PROG_MAX)&&(prog[i].name[0] == 0)){
					pg = &prog[i];
					strcpy(prog[i].name, name);
				}
			}
		}
	}
	return 0;
}


//****************************************************************
//	DEVICEセクション読み込み
//****************************************************************
int conf_device(FILE *fp, DEVICE_CONF device[]){
	char	buff[1024];
	char	data[1024];
	char	name[16];
	DEVICE_CONF	*dv;
	int		i;
	float	f;
	char	c = 0;
	char	*p;
	long	area[AREA_MAX][2];
	long	l;
	char	*dummy;

	dv = NULL;

	while(!feof(fp)){
		buff[0] = 0;
		dummy = fgets(buff, sizeof(buff), fp);
		if (buff[0] == 0)	break;
	  LOOP:
		if (buff[0] == '['){	// セクションが変わる
			str_upr(buff);
			if (strncmp(&buff[1], "DEFAULT",7) == 0)		return 0;
			if (strncmp(&buff[1], "PROGRAMMER", 10) == 0)	return 1;
			if (strncmp(&buff[1], "DEVICE", 6) != 0){
				fprintf(stdout, "Section name error : %s\n", buff);
				return -1;
			}
		} else if (sscanf(buff, " group = %s", data) == 1){
			if (dv != NULL){
				get_comment(buff, data, 16);
				strcpy(dv->group, data);
			}
		} else if (sscanf(buff, " rom = %f%c", &f, &c) >= 1){
			if (dv != NULL){
				if ((c == 'k')||(c == 'K')){
					f *= 1024;
				}
				dv->rom = f;
			}
		} else if (sscanf(buff, " data = %f%c", &f, &c) >= 1){
			if (dv != NULL){
				if ((c == 'k')||(c == 'K')){
					f *= 1024;
				}
				dv->data = f;
			}
		} else if (sscanf(buff, " ram = %f%c", &f, &c) >= 1){
			if (dv != NULL){
				if ((c == 'k')||(c == 'K')){
					f *= 1024;
				}
				dv->ram = f;
			}
		} else if (sscanf(buff, " rom-area = %s", data) == 1){
			p = strchr(buff, '=');
			p++;
			memset(area, 0, sizeof(area));
			i = 0;
			while((strchr(p, '=') == NULL)&&(strchr(p, '}') == NULL)){
				p = get_hex(p, &l);
				if (p != NULL){
					area[i/2][i&1] = l;
					if (++i >= (AREA_MAX*2))	break;
				} else {
					buff[0] = 0;
					dummy = fgets(buff, sizeof(buff), fp);
					if (buff[0] == 0)	break;
					p = buff;
				}
			}
			if (dv != NULL){
				memcpy(dv->rom_area, area, sizeof(area));
			}
			goto LOOP;
		} else if (sscanf(buff, " data-area = %s", data) == 1){
			p = strchr(buff, '=');
			p++;
			memset(area, 0, sizeof(area));
			i = 0;
			while((strchr(p, '=') == NULL)&&(strchr(p, '}') == NULL)){
				p = get_hex(p, &l);
				if (p != NULL){
					area[i/2][i&1] = l;
					if (++i >= (AREA_MAX*2))	break;
				} else {
					buff[0] = 0;
					dummy = fgets(buff, sizeof(buff), fp);
					if (buff[0] == 0)	break;
					p = buff;
				}
			}
			if (dv != NULL){
				memcpy(dv->data_area, area, sizeof(area));
			}
			goto LOOP;
		} else if (sscanf(buff, " comment = %s", data) == 1){
			if (dv != NULL){
				get_comment(buff, data, 64);
				strcpy(dv->comment, data);
			}
		} else if (strchr(buff, '}') != NULL){	// これは最後から一つ前
			dv = NULL;
			// {} がある行に設定は書けないのは仕様です
		} else if (sscanf(buff, " %s", data) == 1){ // これは最後に置くこと
			if ((strchr(buff, '{') != NULL)&&(strlen(data) < 16)){
				strcpy(name, data);
				dv = NULL;
				for (i = 0; i < DEVICE_MAX; i++){
					if (device[i].name[0] == 0)	break;
					if (strcmp(device[i].name, name) == 0){
						dv = &device[i];	// 一致する名前がある場合は上書き
						break;
					}
				}
				if ((dv == NULL)&&(i < DEVICE_MAX)&&(device[i].name[0] == 0)){
					dv = &device[i];
					strcpy(device[i].name, name);
				}
			}
		}
	}
	return 0;
}


//****************************************************************
//	DEFAULTセクション読み込み
//****************************************************************
int conf_default(FILE *fp, OPTION *option){
	char	buff[1024];
	char	data[1024];
	unsigned short	us;
	char	c = 0;
	long	l = 0;
	char	*dummy;

	while(!feof(fp)){
		buff[0] = 0;
		dummy = fgets(buff, sizeof(buff), fp);
		if (buff[0] == 0)	break;

		if (buff[0] == '['){	// セクションが変わる
			str_upr(buff);
			if (strncmp(&buff[1], "PROGRAMMER", 10) == 0)	return 1;
			if (strncmp(&buff[1], "DEVICE", 6) == 0)		return 2;
			if (strncmp(&buff[1], "DEFAULT",7) != 0){
				fprintf(stdout, "Section name error : %s\n", buff);
				return -1;
			}
		} else if (sscanf(buff, " programmer = %s", data) == 1){
			if (strlen(data) < sizeof(option->prog)){
				strcpy(option->prog, data);
			}
		} else if (sscanf(buff, " device = %s", data) == 1){
			if (strlen(data) < sizeof(option->device)){
				strcpy(option->device, data);
			}
		} else if (sscanf(buff, " port = %s", data) == 1){
			if (strlen(data) < sizeof(option->port)){
				strcpy(option->port, data);
			}
		} else if (sscanf(buff, " vid = %04hX", &us) == 1){
			option->vid = us;
		} else if (sscanf(buff, " pid = %04hX", &us) == 1){
			option->pid = us;
		} else if (sscanf(buff, " serial = %s", data) == 1){
			if (strlen(data) < sizeof(option->serial)){
				strcpy(option->serial, data);
			}
		} else if (sscanf(buff, " speed = %ld%c", &l, &c) >= 1){
			if ((c == 'k')||(c == 'K')){
				l *= 1000;
			}
			option->speed = l;
		} else if (sscanf(buff, " file = %s", data) == 1){
			if (strlen(data) < MAX_PATH){
				strcpy(option->mot_fname, data);
			}
		} else if (sscanf(buff, " id-file = %s", data) == 1){
			if (strlen(data) < MAX_PATH){
				strcpy(option->id_fname, data);
			}
		} else if (sscanf(buff, " id = %s", data) == 1){
			// IDを間違えるとデバイスが使えなくなるので要注意
			int		i;
			int		c;
			char	*p;
			unsigned char	id[7];

			p = data;
			for (i = 0; i < 7; i++){
				if (((i > 0)&&(*p++ != ':'))||
					(sscanf(p, "%02X", &c) != 1)){
					fprintf(stdout, "ID error : %s\n", data);
					return -1;
				}
				id[i] = c;
				p += 2;
			}
			memcpy(option->id, id, 7);
		}
	}
	return 0;	
}


//****************************************************************
//	シリアルに16進数取得
//****************************************************************
char *get_hex(char *str, long *hex){
	char	c;
	long	h = 0;

	if ((str == NULL)||(*str == 0))	return NULL;

	while (!isxdigit(*str)){
		if (*str == 0)	return NULL;
		str++;
	}
	if (isxdigit(*str)){
		while(isxdigit(*str)){
			h <<= 4;
			c = *str++;
			if (c >= 'a'){
				c = c - 'a' + 10;
			} else if (c >= 'A'){
				c = c - 'A' + 10;
			} else {
				c &= 0x0F;
			}
			h |= c;
		}
		*hex = h;
	}
	return str;
}


//****************************************************************
//	コメント文字列取得
//****************************************************************
void get_comment(char *buff, char *comment, int max){
	char	*p;
	int		l;
	char	c;

	*comment = 0;
	p = strchr(buff, '=');
	if (p == NULL)	return;
	p++;

	p = skip_space(p);
	if (*p == '"'){
		p++;
		l = 0;
		while(l < max){
			c = *p++;
			if (c == '\t'){
				c = ' ';
			} else if ((c < ' ')||(c == '"')){
				break;	
			}
			*comment++ = c;
			*comment = 0;
			l++;
		}
	} else {
		l = 0;
		while(l < max){
			c = *p++;
			if (c == '\t'){
				c = ' ';
			} else if (c < ' '){
				break;	
			}
			*comment++ = c;
			*comment = 0;
			l++;
		}
	}
}


//****************************************************************
//	空白文字(スペースとタブ)スキップ
//****************************************************************
char *skip_space(char *str){
	while((*str == ' ')||(*str == '\t')){
		str++;
	}
	return str;
}


//****************************************************************
//	文字列大文字化
//****************************************************************
void str_upr(char *str){

	while((*str)){
		*str = toupper(*str);
		str++;
	}
}
