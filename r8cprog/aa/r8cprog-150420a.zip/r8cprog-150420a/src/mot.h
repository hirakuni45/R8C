#ifndef _MOT_H_
#define	_MOT_H_

FILE *open_mot(char *fname);
int	read_mot(FILE *fp, unsigned char *data, int max, long *adrs);
void close_mot(FILE *fp);

int read_hex(unsigned char *p);

#endif	// _MOT_H_
