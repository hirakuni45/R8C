#ifndef _FLASH_H_
#define	_FLASH_H_
//****************************************************************
//	R8C プログラマ
//
//	プログラミング部分
//
//	2009.5.29	KAWAKAMI Yukio
//****************************************************************

#define	R8C_PAGE_READ		0xFF
#define	R8C_PAGE_PROGRAM	0x41
#define	R8C_UNIT_PROGRAM	0x49
#define	R8C_BLOCK_ERASE		0x20
#define	R8C_ERASE_ALL_BLOCK	0xA7
#define	R8C_READ_SRD		0x70
#define	R8C_CLEAR_SRD		0x50
#define	R8C_ID_CHECK		0xF5
#define	R8C_VERSION_INFO	0xFB
#define	R8C_B9600			0xB0
#define	R8C_B19200			0xB1
#define	R8C_B38400			0xB2
#define	R8C_B57600			0xB3
#define	R8C_B115200			0xB4
#define	R8C_BAUD_SET		0xB5

#define	R8C_SRD_IDENTIFIED	0x0C00
#define	R8C_SRD_READY		0x0080
#define	R8C_SRD_ERASE_ERROR	0x0020
#define	R8C_SRD_PROG_ERROR	0x0010

#define	R8C_DELAY		20	// 20ms

int program(COMDAT *com);
int block_erase(COMDAT *com, long adrs);
int chip_erase(COMDAT *com);
int page_write(COMDAT *com, long adrs, unsigned char *buff);
int page_read(COMDAT *com, long adrs, unsigned char *buff);
int wait_ready(COMDAT *com);

int connect_programmer(COMDAT *com);
void disconnect_programmer(COMDAT *com);

int read_status(COMDAT *com);
int send_command(COMDAT *com, unsigned char command);
int read_response(COMDAT *com, int timeout);

void msleep(int n);

void progress(int n, int max);

#endif	// _FLASH_H_
