//****************************************************************
//	R8C プログラマ
//
//	New BSD License
//
//	2009.6.7	KAWAKAMI Yukio
//****************************************************************

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
//#ifdef __MINGW32__
//#include <fcntl.h>
//#endif

#include "com.h"
#include "conf.h"
#include "mot.h"
#include "prog.h"
#include "main.h"

#define	VERSION	"0.1.5"

#define CONF_FILE_NAME	"r8cprog.conf"

DEVICE_CONF	Device[DEVICE_MAX];
PROG_CONF	Prog[PROG_MAX];
OPTION		Option;

COMDAT	Com;	// シリアル
FILE	*Out;	// メッセージ出力先

int main(int argc, char *argv[]){
	int		r;
	int		i;
	char	conf[MAX_PATH];

	r = 0;

	Out = stdout;

	if (argc < 2){
		view_help();	// ヘルプ表示
		return 0;
	}

	memset(&Device, 0, sizeof(Device));
	memset(&Prog, 0, sizeof(Prog));
	memset(&Option, 0, sizeof(Option));
	memset(&Option.id, 0xFF, 7);	// IDデフォルト all FFh
	conf[0] = 0;

	// デバイス未指定
	strcpy(Device[0].name, " ");
	strcpy(Device[0].group, " ");
	Device[0].rom_area[0][0] = 0x4000L;
	Device[0].rom_area[0][1] = 0x43FFFL;	// 256KB
	Device[0].data_area[0][0] = 0x2000L;
	Device[0].data_area[0][1] = 0x3FFFL;	// 8KB


	// コマンドライン先頭の quiet指定だけは先に処理する
	if (strcmp(argv[1], "-q") == 0){
		Out = fopen("/dev/null", "wt");
		Option.quiet_flag = 1;
	}

	// 実行ファイルと同じディレクトリに設定ファイルがあるか調べる
#if defined(__MINGW32__)
	{
		char *p;
		GetModuleFileName(NULL, conf, sizeof conf);
		p = strrchr(conf, '\\');
		if (p) {
			*(p + 1) = '\0';
			strcat(conf, CONF_FILE_NAME);

			if (file_exist(conf)){
				load_conf(conf, Device, Prog, &Option);
			}
		}
	}
#else
	if (strchr(argv[0], '/')){
		if (*argv[0] == '.'){
			char	*dummy;
			dummy = getcwd(conf, sizeof(conf)-1);
			strcat(conf, "/");
			strcat(conf, CONF_FILE_NAME);
			if (file_exist(conf)){
				load_conf(conf, Device, Prog, &Option);
			}
		}
	} else {
		if (!search_path_file(argv[0], conf)){
			load_conf(conf, Device, Prog, &Option);	// あれば読む
		}
	}
#endif
	// カレントディレクトリの設定ファイル読み込み
	{
		char	*dummy;
		dummy = getcwd(conf, sizeof(conf)-1);
	}
	strcat(conf, "/");
	strcat(conf, CONF_FILE_NAME);
	if (file_exist(conf)){
		load_conf(conf, Device, Prog, &Option);
	}

	// コマンドラインオプション解析
	read_command_line(&Option, argc, argv, conf);

	if (conf[0]){
		// コマンドラインで指定した設定ファイル読み込み
		if (file_exist(conf)){
			if (load_conf(conf, Device, Prog, &Option)){
				r = -1;
				goto QUIT;
			}
		} else {
			fprintf(stdout, "Config file not Found : %s\n", conf);
		}
		// 再度コマンドラインオプション解析
		read_command_line(&Option, argc, argv, conf);
	}

	// デバイスデータソート
	for (i = 0; i < DEVICE_MAX; i++){
		if (Device[i].name[0] == 0)	break;
	}
	qsort((void*)&Device, i, sizeof(DEVICE_CONF), cmp_device);

	// プログラマデータソート
	for (i = 0; i < PROG_MAX; i++){
		if (Prog[i].name[0] == 0)	break;
	}
	qsort((void*)&Prog, i, sizeof(PROG_CONF), cmp_prog);

	if (Option.view_device_list){
		view_device_list();		// 設定ファイルのデバイス一覧表示
		goto QUIT;
	}

	if (Option.view_programmer_list){
		view_programmer_list();	// 設定ファイルのプログラマー一覧表示
		goto QUIT;
	}

	if (Option.help_flag){
		view_help();			// ヘルプ表示
		goto QUIT;
	}

	if (Option.view_version){
		printf("Renesas R8C series Programmer Version " VERSION "\r\n");
		goto QUIT;
	}

	if ((Option.erase_flag)&&(Option.device[0] == 0)){
		Option.erase_chip = 1;		// デバイス指定が無い場合はチップ消去
	}

	if (Option.id_fname[0]){	// IDファイルが指定してあれば読み込み
		if (read_id_file(Option.id_fname, Option.id)){
			r = -1;
			goto QUIT;
		}
	}

	if (Option.mot_fname[0]){	// MOTファイル指定がある場合は存在確認
		if (!file_exist(Option.mot_fname)){
			fprintf(stdout, "File not found : %s\n", Option.mot_fname);
			r = -1;
			goto QUIT;
		}
	}

	// R8C接続・作業開始
	r = program(&Com);
	if (!r){
		fprintf(Out, "OK.\n");
	}

  QUIT:
	if (Out){
		fflush(Out);
		fclose(Out);
	}
	return r;
}


//****************************************************************
//	ヘルプ表示
//****************************************************************
void view_help(void){

	printf("Renesas R8C series Programmer Version " VERSION "\r\n");
	printf("usage:\r\n");
	printf("\tr8cprog [options] [mot/id/conf file] ...\n");
	printf("\n");
	printf("Options :\n");
	printf("-d, --device=DEVICE\t\tSpecify device name\n");
	printf("-e, --erase\t\t\tPerform a device erase to a minimum\n");
	printf("-E, --erase-all, --erase-chip\tPerform rom and data flash erase\n");
	printf("    --erase-rom\t\t\tPerform rom flash erase\n");
	printf("    --erase-data\t\tPerform data flash erase\n");
	printf("-i, --id=xx:xx:xx:xx:xx:xx:xx\tSpecify protect ID\n");
	printf("-p, --programmer=PROGRAMMER\tSpecify programmer name\n");
	printf("-P, --port=PORT\t\t\tSpecify serial port\n");
	printf("-q\t\t\t\tQuell progress output\n");
	printf("-r, --read\t\t\tPerform data read\n");
	printf("-s, --speed=SPEED\t\tSpecify serial speed\n");
	printf("-v, --verify\t\t\tPerform data verify\n");
	printf("    --device-list\t\tDisplay device list\n");
	printf("    --programmer-list\t\tDisplay programmer list\n");
	printf("-V, --verbose\t\t\tVerbose output\n");
	printf("-w, --write\t\t\tPerform data write\n");
	printf("-h, --help\t\t\tDisplay this\n");
	printf("    --version\t\t\tDisplay version No.\n");
}


//****************************************************************
//	デバイスリスト表示
//****************************************************************
void view_device_list(void){
	int		i;

	fprintf(Out, "Group     Name            ROM     RAM    DATA  Comment\n");
	for (i = 1; i < DEVICE_MAX; i++){	// 0番目は未指定の場合の内容
		if (Device[i].name[0] == 0)	break;
		fprintf(Out, "%-10s%-14s%3gKB %5gKB ",
			   Device[i].group,
			   Device[i].name,
			   Device[i].rom/1024,
			   Device[i].ram/1024);
		if (Device[i].data){
			fprintf(Out, "%5gKB  %s\n",
				   Device[i].data/1024,
				   Device[i].comment);
		} else {
			fprintf(Out, "      -  %s\n",
				   Device[i].comment);
		}
	}
}


//****************************************************************
//	プログラマリスト表示
//****************************************************************
void view_programmer_list(void){
	int	i;

	fprintf(Out, "Name            Comment\n");
	for (i = 0; i < PROG_MAX; i++){
		if (Prog[i].name[0] == 0)	break;
		fprintf(Out, "%-16s%s\n", Prog[i].name, Prog[i].comment);
	}
}


//****************************************************************
//	デバイスリストのソート用比較関数
//****************************************************************
int cmp_device(const void *d1, const void *d2){
	int		r;

	r = strcmp(((DEVICE_CONF *)d1)->group, ((DEVICE_CONF *)d2)->group);
	if (r)	return r;
	r = strcmp(((DEVICE_CONF *)d1)->name, ((DEVICE_CONF *)d2)->name);
	return r;
}


//****************************************************************
//	プログラマリストのソート用比較関数
//****************************************************************
int cmp_prog(const void *d1, const void *d2){
	int		r;

	r = strcmp(((PROG_CONF *)d1)->name, ((PROG_CONF *)d2)->name);
	return r;
}


//****************************************************************
//	コマンドライン解析
//****************************************************************
void read_command_line(OPTION *opt, int argc, char *argv[], char *conf_file){
	int		i;
	char	*p;
	long	s;
	unsigned char	id[7];

	conf_file[0] = 0;
	for (i = 1; i < argc; i++){
		if (argv[i][0] == ('-')){	// オプションスイッチ
			if (strcmp(argv[i], "-q") == 0){
				if (Out == stdout){
					Out = fopen("/dev/null", "wt");
				}
				opt->quiet_flag = 1;
				opt->verbose_flag = 0;
			} else if ((strcmp(argv[i], "-V") == 0)||
					   (strcmp(argv[i], "--verbose") == 0)){
				opt->quiet_flag = 0;
				opt->verbose_flag = 1;
			} else if ((strcmp(argv[i], "-P") == 0)||
					   (strcmp(argv[i], "--port") == 0)){
				if (++i >= argc)	break;
				if (strlen(argv[i]) < 16){
					strcpy(opt->port, argv[i]);		// ポート名称
				}
			} else if (strncmp(argv[i], "--port=", 7) == 0){
				if (strlen(argv[i]) < (16 + 7)){
					p = argv[i];
					strcpy(opt->port, p+7);
				}
			} else if ((strcmp(argv[i], "-d") == 0)||
					   (strcmp(argv[i], "--device") == 0)){
				if (++i >= argc)	break;
				if (strlen(argv[i]) < 16){
					strcpy(opt->device, argv[i]);	// デバイス名称
				}
			} else if (strncmp(argv[i], "--device=", 9) == 0){
				if (strlen(argv[i]) < (16 + 9)){
					p = argv[i];
					strcpy(opt->device, p+9);
				}
			} else if ((strcmp(argv[i], "-p") == 0)||
					   (strcmp(argv[i], "--programmer") == 0)){
				if (++i >= argc)	break;
				if (strlen(argv[i]) < 16){
					strcpy(opt->prog, argv[i]);		// プログラマ名称
				}
			} else if (strncmp(argv[i], "--programmer=", 13) == 0){
				if (strlen(argv[i]) < (16 + 13)){
					p = argv[i];
					strcpy(opt->prog, p+13);
				}
			} else if ((strcmp(argv[i], "-s") == 0)||
					   (strcmp(argv[i], "--speed") == 0)){
				if (++i >= argc)	break;
				s = atol(argv[i]);
				if (s){
					if ((strchr(argv[i], 'k') != NULL)||
						(strchr(argv[i], 'K') != NULL)){
						s *= 1000L;
					}
					opt->speed = s;		// シリアルポートスピード
				}
			} else if (strncmp(argv[i], "--speed=", 8) == 0){
				p = argv[i];
				p += 8;
				s = atol(p);
				if (s){
					if ((strchr(argv[i], 'k') != NULL)||
						(strchr(argv[i], 'K') != NULL)){
						s *= 1000L;
					}
					opt->speed = s;		// シリアルポートスピード
				}
			} else if ((strcmp(argv[i], "-i") == 0)||
					   (strcmp(argv[i], "--id") == 0)){
				if (++i >= argc)	break;
				if (sscanf(argv[i], "%02x:%02x:%02x:%02x:%02x:%02x:%02x",
						   (unsigned int *)&id[0], (unsigned int *)&id[1],
						   (unsigned int *)&id[2], (unsigned int *)&id[3],
						   (unsigned int *)&id[4], (unsigned int *)&id[5],
						   (unsigned int *)&id[6]) == 7){
					memcpy(opt->id, id, 7);
				}
			} else if (strncmp(argv[i], "--id=", 5) == 0){
				p = argv[i];
				p += 5;
				if (sscanf(p, "%02x:%02x:%02x:%02x:%02x:%02x:%02x",
						   (unsigned int *)&id[0], (unsigned int *)&id[1],
						   (unsigned int *)&id[2], (unsigned int *)&id[3],
						   (unsigned int *)&id[4], (unsigned int *)&id[5],
						   (unsigned int *)&id[6]) == 7){
					memcpy(opt->id, id, 7);
				}
			} else if ((strcmp(argv[i], "-e") == 0)||
					   (strcmp(argv[i], "--erase") == 0)){
				opt->erase_flag = 1;
			} else if ((strcmp(argv[i], "-E") == 0)||
					   (strcmp(argv[i], "--erase-all") == 0)||
					   (strcmp(argv[i], "--erase-chip") == 0)){
				opt->erase_flag = 1;
				opt->erase_rom = 1;
				opt->erase_data = 1;
				opt->erase_chip = 1;
			} else if (strcmp(argv[i], "--erase-rom") == 0){
				opt->erase_flag = 1;
				opt->erase_rom = 1;
			} else if (strcmp(argv[i], "--erase-data") == 0){
				opt->erase_flag = 1;
				opt->erase_data = 1;
			} else if ((strcmp(argv[i], "-w") == 0)||
					   (strcmp(argv[i], "--write") == 0)){
				opt->write_flag = 1;
			}
#if 1
			else if ((strcmp(argv[i], "-r") == 0)||
					   (strcmp(argv[i], "--read") == 0)){
				opt->read_flag = 1;
			}
#endif
			else if ((strcmp(argv[i], "-v") == 0)||
					   (strcmp(argv[i], "--verify") == 0)){
				opt->verify_flag = 1;
			} else if (strcmp(argv[i], "--device-list") == 0){
				opt->view_device_list = 1;
			} else if (strcmp(argv[i], "--programmer-list") == 0){
				opt->view_programmer_list = 1;
			} else if (strcmp(argv[i], "--version") == 0){
				opt->view_version = 1;
				if (Out == stdout){
					Out = fopen("/dev/null", "wt");
				}
			} else if ((strcmp(argv[i], "--help") == 0)||
					   (strcmp(argv[i], "-?") == 0)||
					   (strcmp(argv[i], "-h") == 0)){
				if (Out == stdout){
					Out = fopen("/dev/null", "wt");
				}
				opt->help_flag = 1;
			}
		} else {
			char	fname[MAX_PATH];
			char	*p;
			strcpy(fname, argv[i]);
			str_upr(fname);			// 大文字化
			p = strrchr(fname, '.');
			if (p){
				if ((strcmp(p, ".MOT") == 0)||(strcmp(p, ".S") == 0)){
					strcpy(opt->mot_fname, argv[i]);	// 大文字化する前
				} else if (strcmp(p, ".ID") == 0){
					strcpy(opt->id_fname, argv[i]);		// 大文字化する前
				} else if (strcmp(p, ".CONF") == 0){
					strcpy(conf_file, argv[i]);
				} else {
					fprintf(stdout, "unknown arg : %s\n", argv[i]);
				}
			} else {
				fprintf(stdout, "unknown arg : %s\n", argv[i]);
			}
		}
	}
}


//****************************************************************
//	実行ファイルと同じディレクトリに設定ファイルがあるか調べる
//****************************************************************
int search_path_file(char *argv0, char *conf_fname){
	char	*ps, *pe;
	char	fname[MAX_PATH];

	*conf_fname = 0;

	ps = pe = getenv("PATH");
	while((ps != NULL)&&(*ps)){
		pe = strchr(ps, ':');
		if (pe == NULL){
			if (strlen(ps) >= sizeof(fname))	return -1;	// なぜか長すぎる
			strcpy(fname, ps);
		} else {
			if ((pe-ps+12) >= sizeof(fname))	return -1;	// なぜか長すぎる
			memset(fname, 0, sizeof(fname));
			strncpy(fname, ps, pe-ps);
		}
		strcat(fname, "/");
		strcat(fname, CONF_FILE_NAME);
		if (file_exist(fname)){
			strcpy(conf_fname, fname);
			return 0;
		}
		ps = pe;
		if (ps == NULL)	break;
		ps++;
	}
	return -1;
}


//****************************************************************
//	ファイルの存在確認
//****************************************************************
int file_exist(char *fname){

	FILE	*fp;
	fp = fopen(fname, "rb");
	if (fp == NULL){
		return 0;
	}
	fclose(fp);
	return 1;
}


//****************************************************************
//	idファイル中の ID値読み込み
//****************************************************************
int read_id_file(char *fname, unsigned char id[]){
	FILE	*fp;
	long	adrs;
	int		data;
	char	buff[1024];
	int		ret;

	fp = fopen(fname, "rt");
	if (fp == NULL){
		fprintf(stdout, "ID file not open : %s\n", fname);
		return -1;
	}
	ret = 0;
	while(!feof(fp)){
		char *dummy;

		buff[0] = 0;
		dummy = fgets(buff, sizeof(buff), fp);
		if (buff[0] == 0)	break;

		if (sscanf(buff, "%lX : %X", &adrs, &data) == 2){
			if (data > 0xFF){
				fprintf(stdout, "ID Data error : %lX : %X\n", adrs, data);
				ret = -1;
			} else {
				switch(adrs){
				  case 0x00FFDF:
					id[0] = (unsigned char)data;	break;
				  case 0x00FFE3:
					id[1] = (unsigned char)data;	break;
				  case 0x00FFEB:
					id[2] = (unsigned char)data;	break;
				  case 0x00FFEF:
					id[3] = (unsigned char)data;	break;
				  case 0x00FFF3:
					id[4] = (unsigned char)data;	break;
				  case 0x00FFF7:
					id[5] = (unsigned char)data;	break;
				  case 0x00FFFB:
					id[6] = (unsigned char)data;	break;
				  case 0x00FFFF:
					break;
				  default:
					fprintf(stdout, "ID Address error : %lX\n", adrs);
					ret = -1;
					break;
				}
			}
		}
	}

	fclose(fp);
	return ret;
}



//****************************************************************
//	motファイルの中の ID値読み込み
//****************************************************************
int	read_mot_id(char *fname, unsigned char id[]){
	unsigned char	buff[1024];
	int		i, n;
	FILE	*fp;
	long	adrs;


	fp = open_mot(fname);
	if (fp == NULL)		return -1;

	while(!feof(fp)){
		n = read_mot(fp, buff, sizeof(buff), &adrs);
		if (n > 0){
			for (i = 0; i < n; i++){
				switch(adrs){
				  case 0x00FFDF:
					id[0] = buff[i];	break;
				  case 0x00FFE3:
					id[1] = buff[i];	break;
				  case 0x00FFEB:
					id[2] = buff[i];	break;
				  case 0x00FFEF:
					id[3] = buff[i];	break;
				  case 0x00FFF3:
					id[4] = buff[i];	break;
				  case 0x00FFF7:
					id[5] = buff[i];	break;
				  case 0x00FFFB:
					id[6] = buff[i];	break;
				  default:
					break;
				}
				adrs++;
			}
		}
	}

	close_mot(fp);
	return 0;
}
