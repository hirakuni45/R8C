#ifndef _CONF_H_
#define	_CONF_H_

#define	DEVICE_MAX		128
#define	PROG_MAX		64
#define	AREA_MAX		128

#ifndef MAX_PATH
#define MAX_PATH	256
#endif


typedef struct {
	char	name[16];		// 名称
	char	group[16];		// グループ名称
	float	rom;			// ROM容量(bytes)
	float	data;			// DATAフラッシュ容量(bytes)
	float	ram;			// RAM容量(bytes)

	long	rom_area[AREA_MAX][2];	// ROMエリア
	long	data_area[AREA_MAX][2];	// DATAフラッシュエリア

	char	comment[64];	// コメント
} DEVICE_CONF;

typedef struct {
	char	name[16];		// 名称
	char	comment[64];	// コメント
} PROG_CONF;

typedef struct {
	char	prog[16];		// プログラマ名称
	char	device[16];		// デバイス名称
	char	port[16];		// ポート名称
	long	speed;			// シリアルスピード
	unsigned short	vid;	// USB VID
	unsigned short	pid;	// USB PID
	char	serial[32];		// USBシリアルNo.
	char	mot_fname[MAX_PATH];	// motファイル名
	char	id_fname[MAX_PATH];		// idファイル名
	unsigned char	id[7];	// id
	char	erase_flag;		// 消去実行フラグ
	char	erase_rom;		// ROM全消去フラグ
	char	erase_data;		// DATAフラッシュ消去フラグ
	char	erase_chip;		// チップ全消去フラグ
#if 1
	char	read_flag;		// 読み出しフラグ
#endif
	char	write_flag;		// 書き込みフラグ
	char	verify_flag;	// Verifyフラグ
	char	verbose_flag;	// 詳細メッセージ出力フラグ
	char	quiet_flag;		// メッセージ出力OFFフラグ
	char	view_device_list;		// デバイスリスト出力フラグ
	char	view_programmer_list;	// プログラマーリスト出力フラグ
	char	view_version;			// バージョン表示
	char	help_flag;				// ヘルプ表示フラグ
} OPTION;

int load_conf(char *conf_fname, DEVICE_CONF device[], PROG_CONF prog[], OPTION *option);

int conf_prog(FILE *fp, PROG_CONF prog[]);
int conf_device(FILE *fp, DEVICE_CONF device[]);
int conf_default(FILE *fp, OPTION *option);

void get_comment(char *buff, char *comment, int max);
char *get_hex(char *str, long *hex);

char *skip_space(char *str);

void str_upr(char *str);

#endif	// _CONF_H_
