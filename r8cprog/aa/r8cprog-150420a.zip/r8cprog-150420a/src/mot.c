
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "mot.h"


//********************************************************
//	モトローラＳフォーマットファイルオープン
//********************************************************
FILE *open_mot(char *fname){
	unsigned char	buff[1024];
	FILE	*fp;

	fp = fopen(fname, "rt");
	if (fp == NULL){
		fprintf(stdout, "File not open : %s\n", fname);
		return NULL;
	}

	// ヘッダ確認
	buff[0] = 0;
	if (fgets((char *)buff, sizeof(buff), fp) == NULL){
		fprintf(stdout, "File read error : %s\n", fname);
		return NULL;
	}

	if (strncmp((char *)buff, "S0", 2) != 0){
		fprintf(stdout, "File is not S format : %s\n", fname);
		return NULL;
	}

	return fp;
}


//********************************************************
//	モトローラＳフォーマットファイルクローズ
//********************************************************
void close_mot(FILE *fp){
	fclose(fp);
}


//********************************************************
//	モトローラ Sフォーマットファイル１行読み込み
//	ヘッダレコードは open_mot()で読み込んだはず
//	チェックサムは無視
//
//	戻り値：取得データ数
//		==0:終了
//		< 0:エラー
//********************************************************
int	read_mot(FILE *fp, unsigned char *data, int max, long *adrs){
	unsigned char	buff[1024];
	unsigned char	*p;
	int				i, n, count;
	long			l;

	assert(fp);
	assert(data);

	buff[0] = 0;
	if (fgets((char *)buff, sizeof(buff), fp) == NULL)	return -1;

	if (buff[0] == 0)	return 0;
	if (buff[0] != 'S')	return -1;
	if (buff[1] == '0')	return -1;	// open_mot()で読んだはず

	if ((buff[1] == '7')||
		(buff[1] == '8')||
		(buff[1] == '9'))	return 0;	// エンドレコード

	p = &buff[2];
	count = read_hex(p);
	if (count <= 0)		return -1;

	p += 2;
	l = 0;
	switch(buff[1]){
	  case '3':
		n = read_hex(p);	p += 2;
		if (n < 0)	return -1;
		l |= n;
		--count;
	  case '2':
		l <<= 8;
		n = read_hex(p);	p += 2;
		if (n < 0)	return -1;
		l |= n;
		--count;
	  case '1':	
		l <<= 8;
		n = read_hex(p);	p += 2;
		if (n < 0)	return -1;
		l |= n;
		l <<= 8;
		n = read_hex(p);	p += 2;
		if (n < 0)	return -1;
		l |= n;
		*adrs = l;
		count -= 2;
		break;

	  default:
		return -1;
	}

	i = count - 1;
	if (i > max)	return -1;		// バッファあふれ
		
	while(i > 0){
		n = read_hex(p);	p += 2;
		if (n < 0)		return  -1;
		*data++ = (unsigned char)n;
		--i;
	}

	// チェックサムの分
	n = read_hex(p);
	if (n < 0)	return -1;

	return (count - 1);
}


//********************************************************
//	１６進数２桁読み込み
//********************************************************
int read_hex(unsigned char *p){
	unsigned char	c;

	if ((p == NULL)||(!isxdigit(*p)))	return -1;

	if (*p >= 'a'){
		c = (*p++) - 'a' + 10;
	} else if (*p >= 'A'){
		c = (*p++) - 'A' + 10;
	} else {
		c = (*p++) & 0x0F;
	}
	c <<= 4;

	if (!isxdigit(*p))		return -1;
	if (*p >= 'a'){
		c |= (*p++) - 'a' + 10;
	} else if (*p >= 'A'){
		c |= (*p++) - 'A' + 10;
	} else {
		c |= (*p++) & 0x0F;
	}

	return c;
}
